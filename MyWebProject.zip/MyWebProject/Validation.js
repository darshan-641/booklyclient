function checkEmptyField(fieldId) {
 
    alert('checkEmptyField '+fieldId);
    
}

const validateBirthday = (birthday) => {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(birthday)) {
        return -1;
    }
    let parts = birthday.split('-');
    let now = new Date();
    let year = parseInt(parts[0], 10);
    let currentYear = now.getFullYear();
    let month = ( parts[1][0] === '0') ? parseInt(parts[1][1], 10) : parseInt(parts[1], 10);
    let day = ( parts[2][0] === '0') ? parseInt(parts[2][1], 10) : parseInt(parts[2], 10);

    if(year >= currentYear) {
        return -1;
    }
    if( (currentYear - year) < 18 || (currentYear - year) > 80) {
        return -1;
    }
    if( month < 1 || month > 12) {
        return -1;
    }
    if( day < 1 || day > 31 ) {
        return -1;
    }
    return 0;

function validate(){
    // alert("Entered xyz");
    alert("Entered validate");
    var name = document.getElementById("uname").value;

    var password = document.getElementById("upass").value;
    
    if( name == "" ){
        document.getElementById("nameErr").innerHTML="Name Field cannot be let blank";
        // alert("Name Field cannot be let blank");
        return false;
    }
    else if( password == ""){
        document.getElementById("passErr").innerHTML="Password Field cannot be let blank";
        // alert("Name Field cannot be let blank");
        return false;
    }
    else if( name.length <8) {
        alert("Name must have atleast 8 character");
        return false;
    }
    else if ( password.length <8){
        alert("Password should be of atleast 8 character");
        return false;
    }
    else return true;
}


function clear(){
		
    document.getElementById("uname").value ="";
    document.getElementById("upass").value="";

}

function clearNameErr(){
   document.getElementById("uname").innerHTML="";
}

function clearPassErr(){
       document.getElementById("upass").innerHTML= "";
}