

function validate(){
    var name = document.getElementById("uname").value;
    var email = document.getElementById("uemail").value;
    var password = document.getElementById("upass").value;
    alert("Entered validate");
    if( name == ""|| password == "" || email == ""){
        alert("Field cannot be let blank");
        return false;
    }
    else return true;
}