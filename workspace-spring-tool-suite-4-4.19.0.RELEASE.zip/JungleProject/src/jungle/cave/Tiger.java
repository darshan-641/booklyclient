package jungle.cave;



public class Tiger {
	
	
	private void privateMethodA()
	{
//		Byte rollNo = new Byte((byte) 127);
		
		System.out.println("Tiger is privateMethodA");
	}
	
	protected void protectedMethodB()
	{
		System.out.println("Tiger is protectedMethodB");
	}
	
	public void publicMethodC()
	{
		System.out.println("Tiger is publicMethodC");
	}
	
	void defaultMethodD()
	{
		System.out.println("Tiger is defaultMethodD");
	}
}

class WhiteTiger extends Tiger{
void roaming(Tiger tiger)
{
//	Tiger tiger=new Tiger();
//	tiger.privateMethodA(); //showing error because of private avaliable for same classtiger.protectedMethodB();
	tiger.publicMethodC();
//	tiger.defaultMethodD();
}
}



