
public class ClassExtension2 {

}
