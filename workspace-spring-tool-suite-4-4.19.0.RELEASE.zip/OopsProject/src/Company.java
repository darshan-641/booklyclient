
public class Company {

	public static void main(String[] args) {
		
		CEO x = new Employee();
		

	}

}
class Car{
	
}

class Sedan extends Car{
	
}

class Director extends Manager{
	
}

class CEO extends Director{
	
}
